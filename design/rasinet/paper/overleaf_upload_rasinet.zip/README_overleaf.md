# Overleaf Instructions

This folder is a self-contained LaTeX paper draft.

Upload these items to Overleaf:

- `main.tex`
- `references.bib`
- the full `figures/` folder

The paper uses PDF figures already generated under `figures/`. The `tables/` folder is not required for compilation because the paper tables are embedded in `main.tex`, but keep it as the source-of-truth audit trail for numbers.

Recommended Overleaf settings:

- Compiler: pdfLaTeX
- Bibliography tool: BibTeX
- Main file: `main.tex`

Local compile check used:

```powershell
cd D:\MRI\rasinet\paper
pdflatex main.tex
```
